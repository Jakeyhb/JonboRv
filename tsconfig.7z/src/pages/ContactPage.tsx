// src/pages/ContactPage.tsx
import React from 'react';

const ContactPage: React.FC = () => {
  return (
    <div>
      <h1>Contact Page</h1>
      <p>This is the contact page.</p>
    </div>
  );
};

export default ContactPage;
